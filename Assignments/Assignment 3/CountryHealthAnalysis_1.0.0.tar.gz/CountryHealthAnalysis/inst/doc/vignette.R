## ----setup, include = FALSE---------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)
library(CountryHealthAnalysis)
library(ggplot2)

## ----read---------------------------------------------------------------------
irlPath <- system.file("extdata", "indicators_irl.csv", package = "CountryHealthAnalysis")
mltPath <- system.file("extdata", "indicators_mlt.csv", package = "CountryHealthAnalysis")

irl <- readIndicators(irlPath)
mlt <- readIndicators(mltPath)

## ----print-default------------------------------------------------------------
print(irl)

## ----print-custom-------------------------------------------------------------
print(irl, indicatorList = c("Net migration", "Urban population (% of total)"))

## ----summary-default----------------------------------------------------------
summary(mlt)

## ----summary-custom-----------------------------------------------------------
summary(mlt, indicatorList = c("CO2 emissions (metric tons per capita)", "Population, total"))

## ----summary-topN-------------------------------------------------------------
summary(irl, topN = 10)

## ----plot-default-------------------------------------------------------------
plot(irl)

## ----plot-custom--------------------------------------------------------------
plot(irl, indicatorList = c("Net migration", "School enrollment, primary (% gross)"))

## ----plot-facet---------------------------------------------------------------
plot(mlt, topN = 5, facet = TRUE)

